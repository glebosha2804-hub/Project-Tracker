package com.example.tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrackerApplication {
  public static void main(String[] args) {
    SpringApplication.run(TrackerApplication.class, args);
  }
}
